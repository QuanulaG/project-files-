package com.example.rainbow;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    LinearLayout RainbowLayoutBackground;
    Button Orange;
    Button Red;
    Button Yellow;
    Button Green;
    Button Blue;
    Button Purple;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final LinearLayout RainbowLayoutBackground = findViewById(R.id.RainbowLayoutBackground);
        RainbowLayoutBackground.setBackgroundColor(getResources().getColor(android.R.color.black));

     Orange=findViewById(R.id.Orange);
     Red=findViewById(R.id.Red);
     Yellow=findViewById(R.id.Yellow);
     Green=findViewById(R.id.Green);
     Blue=findViewById(R.id.Blue);
     Purple=findViewById(R.id.Purple);

     Orange.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             RainbowLayoutBackground.setBackgroundColor(getResources().getColor(R.color.Orange));
         }
     });
     Red.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             RainbowLayoutBackground.setBackgroundColor(getResources().getColor(R.color.Red));
         }
     });
     Yellow.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             RainbowLayoutBackground.setBackgroundColor(getResources().getColor(R.color.Yellow));
         }
     });
     Green.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             RainbowLayoutBackground.setBackgroundColor(getResources().getColor(R.color.Green));
         }
     });
     Blue.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             RainbowLayoutBackground.setBackgroundColor(getResources().getColor(R.color.Blue));
         }
     });
     Purple.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             RainbowLayoutBackground.setBackgroundColor(getResources().getColor(R.color.Purple));
         }
     });
    }
}